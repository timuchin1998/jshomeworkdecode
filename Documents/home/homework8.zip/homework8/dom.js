////////////////////////homework DOM///////////////////////////////
//////////////////////////////1////////////////////////////
// function enterSum (){
//     if(enterSum){
//         let lastNumber = document.getElementById('ipnutSum').value % 10;
//         max = parseInt(lastNumber / 10);
//         let maxSum=lastNumber + max;
//         console.log(maxSum+lastNumber); 
//     }
// }
////////////////////////////2/////////////////////////

// function entertext(){
//  let input1 = document.getElementById('input1');
// 	let input2 = document.getElementById('input2');
// 	let input1Value = input1.value;
// 	let input2Value = input2.value;
// 	input1.value = input2Value;
// 	input2.value = input1Value;
// }


////////////////////////3////////////////////
// const btn = document.getElementById('btn');

// btn.onclick = () =>{
//     if(btn.style.background === 'red'){
//         btn.style.backgroun12d = 'yellow';
//     }else{
//            btn.style.background = 'red';
//     }
// }
////////////////////4/////////////////////
// function btnBlock(){
//     let input = document.getElementById('input');
//     input.desabled = true;
// }
// function btnUnblock(){
//     let input = document.getElementById('input');
//     input.desabled = false;
// }
